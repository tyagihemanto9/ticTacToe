package com.example.uttamca

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText
    private lateinit var btnAdd: Button
    private lateinit var listView: ListView
    private lateinit var adapter: TodoAdapter
    private val todoList = ArrayList<TodoItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)
        btnAdd = findViewById(R.id.btnAdd)
        listView = findViewById(R.id.listView)

        adapter = TodoAdapter(this, todoList)
        listView.adapter = adapter

        btnAdd.setOnClickListener {
            val newItemName = editText.text.toString()
            if (newItemName.isNotEmpty()) {
                showDateTimePicker(newItemName)
            }
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val item = todoList[position]
            if (item.deadline == null || Date().before(item.deadline)) {
                // Item can be removed
                AlertDialog.Builder(this)
                    .setTitle("Remove Item")
                    .setMessage("Do you want to remove this item?")
                    .setPositiveButton("Yes") { _, _ ->
                        todoList.removeAt(position)
                        adapter.notifyDataSetChanged()
                    }
                    .setNegativeButton("No", null)
                    .show()
            } else {
                // Item cannot be removed after deadline
                AlertDialog.Builder(this)
                    .setTitle("Cannot Remove Item")
                    .setMessage("This item cannot be removed after the deadline.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun showDateTimePicker(itemName: String) {
        val calendar = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, monthOfYear)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hourOfDay, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                calendar.set(Calendar.MINUTE, minute)

                val deadline = calendar.time
                val newItem = TodoItem(itemName, deadline)
                todoList.add(newItem)
                adapter.notifyDataSetChanged()
                editText.text.clear()
            }

            TimePickerDialog(this, timeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
        }

        DatePickerDialog(this, dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
    }
}

data class TodoItem(val name: String, val deadline: Date?)

class TodoAdapter(context: Context, private val items: List<TodoItem>) :
    ArrayAdapter<TodoItem>(context, android.R.layout.simple_list_item_1, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_1, parent, false)
        val textView = view.findViewById<TextView>(android.R.id.text1)
        val item = items[position]
        val formattedDeadline = if (item.deadline != null) SimpleDateFormat("EEE, MMM d, yyyy 'at' hh:mm a", Locale.getDefault()).format(item.deadline) else "No deadline"
        textView.text = "${item.name.toUpperCase(Locale.getDefault())} - Deadline: $formattedDeadline"
        return view
    }
}
